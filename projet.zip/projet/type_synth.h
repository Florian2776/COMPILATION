#ifndef TYPE_SYNTH
#define TYPE_SYNTH

typedef enum {
  BOOL,
  ARITH,
  ERR_BY_0,
  ERR_BY_TYPE
} type_synth;

int min(int a, int b);

int max(int a, int b);

#endif
