#ifndef TYPE_SYNTH
#define TYPE_SYNTH

typedef enum {
  BOOL,
  ARITH,
  ERR_BY_0,
  ERR_BY_TYPE
} type_synth;

#endif
